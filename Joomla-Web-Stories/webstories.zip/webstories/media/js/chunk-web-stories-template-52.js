(window["__webStories_webpackJsonp"] = window["__webStories_webpackJsonp"] || []).push([[177],{

/***/ 282:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var _web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__);
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * External dependencies
 */

/* harmony default export */ __webpack_exports__["default"] = ({
  slug: 'an-artists-legacy',
  creationDate: '2021-08-25T00:00:00.000Z',
  title: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('An Artist’s Legacy', 'template name', 'web-stories'),
  tags: [Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Arts & Crafts', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Paint', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Artist', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Story', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Gray', 'template keyword', 'web-stories')],
  colors: [{
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Lavender Gray', 'color', 'web-stories'),
    color: '#eaeef4',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Gray', 'color', 'web-stories')
  }, {
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Baby Beluga Gray', 'color', 'web-stories'),
    color: '#4d4c48',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Gray', 'color', 'web-stories')
  }, {
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Pale Orange', 'color', 'web-stories'),
    color: '#ffdcc0',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Orange', 'color', 'web-stories')
  }, {
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Meringue White', 'color', 'web-stories'),
    color: '#fbf5f1',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('White', 'color', 'web-stories')
  }],
  description: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('With its artistic brush strokes, white background, and art gallery-like arrangement of photos, this template will let you create beautiful stories around painting, sculpting and other arts and crafts.', 'web-stories'),
  vertical: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Arts & Crafts', 'template vertical', 'web-stories')
});

/***/ })

}]);