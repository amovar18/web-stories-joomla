(window["__webStories_webpackJsonp"] = window["__webStories_webpackJsonp"] || []).push([[75,137],{

/***/ 187:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _template__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(457);
var _template__WEBPACK_IMPORTED_MODULE_0___namespace = /*#__PURE__*/__webpack_require__.t(457, 1);
/* harmony import */ var _metaData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(301);
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Internal dependencies
 */


/* harmony default export */ __webpack_exports__["default"] = ({ ..._metaData__WEBPACK_IMPORTED_MODULE_1__["default"],
  ..._template__WEBPACK_IMPORTED_MODULE_0__
});

/***/ }),

/***/ 301:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var _web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__);
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * External dependencies
 */

/* harmony default export */ __webpack_exports__["default"] = ({
  slug: 'honeymooning-in-italy',
  creationDate: '2021-07-29T00:00:00.000Z',
  title: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Honeymooning in Italy', 'template name', 'web-stories'),
  tags: [Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Travel', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Outdoor', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Floral', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Collage', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Brown', 'template keyword', 'web-stories')],
  colors: [{
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Night Green', 'color', 'web-stories'),
    color: '#232c27',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Green', 'color', 'web-stories')
  }, {
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Light Brownish Pink', 'color', 'web-stories'),
    color: '#f2e5d6',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Pink', 'color', 'web-stories')
  }, {
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Parchment White', 'color', 'web-stories'),
    color: '#fef6df',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('White', 'color', 'web-stories')
  }],
  description: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('With its elegant typography, charming colors and exquisite floral design pattern, this template will let you create lush travel guides, itineraries, bucket lists, travelogues and more.', 'web-stories'),
  vertical: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Travel', 'template vertical', 'web-stories')
});

/***/ })

}]);