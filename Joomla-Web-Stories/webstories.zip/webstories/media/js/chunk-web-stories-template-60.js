(window["__webStories_webpackJsonp"] = window["__webStories_webpackJsonp"] || []).push([[178],{

/***/ 283:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var _web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__);
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * External dependencies
 */

/* harmony default export */ __webpack_exports__["default"] = ({
  slug: 'art-books-gift-guide',
  creationDate: '2021-08-09T00:00:00.000Z',
  title: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Art Books Gift Guide', 'template name', 'web-stories'),
  tags: [Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Art', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Gift', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Recommendation', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Books', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Pink', 'template keyword', 'web-stories')],
  colors: [{
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Petal Pink', 'color', 'web-stories'),
    color: '#da9bb2',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Pink', 'color', 'web-stories')
  }, {
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Milano Red', 'color', 'web-stories'),
    color: '#c01e00',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Red', 'color', 'web-stories')
  }, {
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('White', 'color', 'web-stories'),
    color: '#fff',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('White', 'color', 'web-stories')
  }, {
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Voodoo Purple', 'color', 'web-stories'),
    color: '#412c47',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Purple', 'color', 'web-stories')
  }],
  description: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('With its serene, comforting colors and beautiful illustrations, this template is great for creating stories about books and literature. Review books, talk about the newest releases in fiction, create reading lists and more.', 'web-stories'),
  vertical: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Arts & Crafts', 'template vertical', 'web-stories')
});

/***/ })

}]);