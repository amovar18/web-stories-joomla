(window["__webStories_webpackJsonp"] = window["__webStories_webpackJsonp"] || []).push([[106,168],{

/***/ 215:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _template__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(485);
var _template__WEBPACK_IMPORTED_MODULE_0___namespace = /*#__PURE__*/__webpack_require__.t(485, 1);
/* harmony import */ var _metaData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(329);
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Internal dependencies
 */


/* harmony default export */ __webpack_exports__["default"] = ({ ..._metaData__WEBPACK_IMPORTED_MODULE_1__["default"],
  ..._template__WEBPACK_IMPORTED_MODULE_0__
});

/***/ }),

/***/ 329:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var _web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__);
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * External dependencies
 */

/* harmony default export */ __webpack_exports__["default"] = ({
  slug: 'sustainability-tips',
  creationDate: '2021-08-25T00:00:00.000Z',
  title: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Sustainability Tips', 'template name', 'web-stories'),
  tags: [Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Health & Wellness', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Sustainability', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Environment', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Tips', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Green', 'template keyword', 'web-stories')],
  colors: [{
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Eco Green', 'color', 'web-stories'),
    color: '#134f3c',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Green', 'color', 'web-stories')
  }, {
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Acorn Orange', 'color', 'web-stories'),
    color: '#bb7c48',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Orange', 'color', 'web-stories')
  }, {
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Light Dutch White', 'color', 'web-stories'),
    color: '#fdf0d6',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('White', 'color', 'web-stories')
  }],
  description: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('This template’s soft earthly colors and readable font will let you create beautiful and calming stories for nature topics. Add your own illustrations and create infographics, how-to guides and more.', 'web-stories'),
  vertical: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Health & Wellness', 'template vertical', 'web-stories')
});

/***/ })

}]);