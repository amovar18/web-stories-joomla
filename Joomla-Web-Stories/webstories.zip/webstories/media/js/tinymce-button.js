/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "../media/com_webstories/js/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 9);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

(function() { module.exports = window["React"]; }());

/***/ }),
/* 1 */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["data"]; }());

/***/ }),
/* 2 */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["i18n"]; }());

/***/ }),
/* 3 */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["components"]; }());

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

if (false) { var throwOnDirectAccess, ReactIs; } else {
  // By explicitly using `prop-types` you are opting into new production behavior.
  // http://fb.me/prop-types-in-prod
  module.exports = __webpack_require__(7)();
}


/***/ }),
/* 5 */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["element"]; }());

/***/ }),
/* 6 */
/***/ (function(module, exports) {

(function() { module.exports = window["wp"]["compose"]; }());

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = __webpack_require__(8);

function emptyFunction() {}
function emptyFunctionWithReset() {}
emptyFunctionWithReset.resetWarningCache = emptyFunction;

module.exports = function() {
  function shim(props, propName, componentName, location, propFullName, secret) {
    if (secret === ReactPropTypesSecret) {
      // It is still safe when called from React.
      return;
    }
    var err = new Error(
      'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
      'Use PropTypes.checkPropTypes() to call them. ' +
      'Read more at http://fb.me/use-check-prop-types'
    );
    err.name = 'Invariant Violation';
    throw err;
  };
  shim.isRequired = shim;
  function getShim() {
    return shim;
  };
  // Important!
  // Keep this list in sync with production version in `./factoryWithTypeCheckers.js`.
  var ReactPropTypes = {
    array: shim,
    bool: shim,
    func: shim,
    number: shim,
    object: shim,
    string: shim,
    symbol: shim,

    any: shim,
    arrayOf: getShim,
    element: shim,
    elementType: shim,
    instanceOf: getShim,
    node: shim,
    objectOf: getShim,
    oneOf: getShim,
    oneOfType: getShim,
    shape: getShim,
    exact: getShim,

    checkPropTypes: emptyFunctionWithReset,
    resetWarningCache: emptyFunction
  };

  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

module.exports = ReactPropTypesSecret;


/***/ }),
/* 9 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// NAMESPACE OBJECT: ./packages/tinymce-button/src/store/actions.js
var actions_namespaceObject = {};
__webpack_require__.r(actions_namespaceObject);
__webpack_require__.d(actions_namespaceObject, "setSettings", function() { return setSettings; });
__webpack_require__.d(actions_namespaceObject, "toggleModal", function() { return toggleModal; });
__webpack_require__.d(actions_namespaceObject, "setEditor", function() { return setEditor; });
__webpack_require__.d(actions_namespaceObject, "setCurrentView", function() { return setCurrentView; });
__webpack_require__.d(actions_namespaceObject, "setViewSettings", function() { return setViewSettings; });

// NAMESPACE OBJECT: ./packages/tinymce-button/src/store/selectors.js
var selectors_namespaceObject = {};
__webpack_require__.r(selectors_namespaceObject);
__webpack_require__.d(selectors_namespaceObject, "getSettings", function() { return getSettings; });
__webpack_require__.d(selectors_namespaceObject, "getModal", function() { return getModal; });
__webpack_require__.d(selectors_namespaceObject, "getEditor", function() { return getEditor; });
__webpack_require__.d(selectors_namespaceObject, "getCurrentView", function() { return getCurrentView; });
__webpack_require__.d(selectors_namespaceObject, "getCurrentViewSettings", function() { return getCurrentViewSettings; });
__webpack_require__.d(selectors_namespaceObject, "getState", function() { return getState; });

// EXTERNAL MODULE: external "React"
var external_React_ = __webpack_require__(0);
var external_React_default = /*#__PURE__*/__webpack_require__.n(external_React_);

// EXTERNAL MODULE: external ["wp","element"]
var external_wp_element_ = __webpack_require__(5);

// EXTERNAL MODULE: external ["wp","data"]
var external_wp_data_ = __webpack_require__(1);

// EXTERNAL MODULE: external ["wp","i18n"]
var external_wp_i18n_ = __webpack_require__(2);

// CONCATENATED MODULE: ./packages/tinymce-button/src/store/name.js
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// eslint-disable-next-line no-global-assign
/* harmony default export */ var store_name = (name = 'web-stories-mce');
// CONCATENATED MODULE: ./packages/tinymce-button/src/store/actions.js
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function setSettings(settings) {
  return {
    type: 'SET_SETTINGS',
    settings: settings
  };
}
function toggleModal(open) {
  return {
    type: 'TOGGLE_MODAL',
    modalOpen: open
  };
}
function setEditor(editor) {
  return {
    type: 'SET_EDITOR',
    editor: editor
  };
}
/**
 * Set current view.
 *
 * @param {string} view Current view.
 * @return {Object} Current view action object.
 */

function setCurrentView(view) {
  return {
    type: 'SET_CURRENT_VIEW',
    currentView: view
  };
}
/**
 * Set view settings.
 *
 * @param {Array} view Views list.
 * @param {Object} settings Settings object.
 * @return {Object} View settings object.
 */

function setViewSettings(view, settings) {
  return {
    type: 'SET_VIEW_SETTINGS',
    view: view,
    settings: settings
  };
}
// CONCATENATED MODULE: ./packages/tinymce-button/src/utils/globals.js
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const {
  webStoriesData
} = window;
// CONCATENATED MODULE: ./packages/tinymce-button/src/utils/index.js
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



/**
 * Get current view.
 *
 * @return {string} View name.
 */

const utils_currentView = () => {
  return Object(external_wp_data_["select"])(store_name).getCurrentView();
};
/**
 * Update the view wide settings.
 *
 * @param {Object} args Arguments.
 * @param {Object} args.fieldObj Field object.
 * @param {Object} args.field Field.
 * @param {boolean} [args.hidden=false] Whether the field is hidden.
 * @return {void}
 */

const updateViewSettings = ({
  fieldObj,
  field,
  hidden = false
}) => {
  const currentViewSettings = Object(external_wp_data_["select"])(store_name).getCurrentViewSettings();
  let updatedSettings = currentViewSettings;

  switch (typeof fieldObj) {
    case 'object':
      if (!hidden) {
        const {
          show
        } = fieldObj;
        updatedSettings = { ...currentViewSettings,
          [field]: { ...fieldObj,
            show: !show
          }
        };
      }

      break;

    default:
      updatedSettings = { ...currentViewSettings,
        [field]: fieldObj
      };
      break;
  }

  Object(external_wp_data_["dispatch"])(store_name).setViewSettings(utils_currentView(), updatedSettings);
};
/**
 * Set default setting state per se view type.
 *
 * @return {Object} Settings.
 */

const setDefaultStateSetting = () => {
  const state = [];
  const {
    views,
    fields
  } = webStoriesData;
  views.forEach(value => {
    const {
      value: viewType
    } = value;
    const {
      title,
      author,
      date,
      excerpt,
      archive_link,
      sharp_corners
    } = fields[viewType];
    state[viewType] = {
      title: title,
      excerpt: excerpt,
      author: author,
      date: date,
      archive_link: archive_link,
      archive_link_label: '',
      circle_size: 150,
      sharp_corners: sharp_corners,
      image_alignment: 'left',
      number_of_columns: 1,
      number_of_stories: 5,
      order: 'DESC',
      orderby: 'post_title',
      view: viewType
    };
  });
  return state;
};
/**
 * Build the shortcode tag based on the selected attributes.
 *
 * @return {string} Shortcode.
 */

const utils_prepareShortCode = () => {
  let shortCode = `[web_stories`;
  const editorInstance = Object(external_wp_data_["select"])(store_name).getEditor();
  const settings = Object(external_wp_data_["select"])(store_name).getCurrentViewSettings();

  if (editorInstance) {
    Object.keys(settings).forEach(value => {
      const ValueObject = settings[value];
      const Value = 'object' === typeof ValueObject ? ValueObject.show.toString() : ValueObject.toString();
      shortCode += ` ${value.toString()}="${Value}"`;
    });
  }

  shortCode += ' /]';
  return shortCode;
};
// CONCATENATED MODULE: ./packages/tinymce-button/src/store/default.js
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Internal dependencies
 */

const DEFAULT_STATE = {
  settings: {},
  modalOpen: false,
  editor: false,
  currentView: 'circles'
};
DEFAULT_STATE['settings'] = setDefaultStateSetting();
/* harmony default export */ var store_default = (DEFAULT_STATE);
// CONCATENATED MODULE: ./packages/tinymce-button/src/store/reducers.js
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Internal dependencies
 */

/**
 * Store reducer.
 *
 * @param {Object} state Current state for the data store.
 * @param {Object} action Action object for manipulating state.
 * @return {Object} New Manipulated state for the store.
 */

function reducer(state = store_default, action) {
  switch (action.type) {
    case 'SET_SETTINGS':
      return { ...state,
        settings: action.settings
      };

    case 'TOGGLE_MODAL':
      return { ...state,
        modalOpen: action.modalOpen
      };

    case 'SET_EDITOR':
      return { ...state,
        editor: action.editor
      };

    case 'SET_CURRENT_VIEW':
      return { ...state,
        currentView: action.currentView
      };

    case 'SET_VIEW_SETTINGS':
      return { ...state,
        settings: { ...state.settings,
          [action.view]: action.settings
        }
      };

    default:
      return state;
  }
}

/* harmony default export */ var reducers = (reducer);
// CONCATENATED MODULE: ./packages/tinymce-button/src/store/selectors.js
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */


/**
 * Retrieve settings.
 *
 * @param {Object} state State of store.
 * @return {Object} Settings object.
 */

function getSettings(state) {
  return state.settings;
}
/**
 * Get Modal state.
 *
 * @param  {Object} state State of the store.
 * @return {boolean} Flag for open state of modal.
 */

function getModal(state) {
  return state.modalOpen;
}
/**
 * Get editor instance.
 *
 * @param {Object} state State for the store.
 * @return {string} Editor ID.
 */

function getEditor(state) {
  return state.editor;
}
/**
 * Get current view for the store.
 *
 * @param {Object} state State object.
 * @return {string} Current view name.
 */

function getCurrentView(state) {
  return state.currentView;
}
/**
 *Get settings for current view.
 *
 * @param {Object} state State object.
 * @return {Object} Settings object for current view.
 */

function getCurrentViewSettings(state) {
  const currentView = Object(external_wp_data_["select"])(store_name).getCurrentView();
  return state.settings[currentView];
}
function getState(state) {
  return state;
}
// CONCATENATED MODULE: ./packages/tinymce-button/src/store/index.js
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */





/**
 * Create a store.
 */

const WebStoryMCEStore = Object(external_wp_data_["registerStore"])(store_name, {
  actions: actions_namespaceObject,
  reducer: reducers,
  selectors: selectors_namespaceObject
});
/* harmony default export */ var store = (WebStoryMCEStore);
// EXTERNAL MODULE: external ["wp","compose"]
var external_wp_compose_ = __webpack_require__(6);

// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(4);

// EXTERNAL MODULE: external ["wp","components"]
var external_wp_components_ = __webpack_require__(3);

// CONCATENATED MODULE: ./packages/tinymce-button/src/components/controls/Toggle.js


/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


/**
 * Toggle component for TinyMCE popup.
 *
 * @param {Object} props Component props.
 * @return {*} React component.
 */

const TinyMceToggle = props => {
  const {
    fieldObj = {},
    field
  } = props;
  const {
    show,
    hidden,
    label
  } = fieldObj;

  if (hidden) {
    return null;
  }

  return /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["ToggleControl"], {
    label: label,
    checked: show,
    onChange: () => {
      updateViewSettings({
        fieldObj: fieldObj,
        field: field,
        hidden
      });
    }
  });
};

/* harmony default export */ var Toggle = (TinyMceToggle);
// CONCATENATED MODULE: ./packages/tinymce-button/src/components/Modal.js


/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */






const WebStoriesModal = props => {
  const {
    modalOpen,
    settings,
    prepareShortCode
  } = props;
  const {
    author,
    date,
    title,
    number_of_stories,
    order,
    orderby,
    view,
    excerpt,
    image_alignment,
    archive_link,
    circle_size,
    number_of_columns,
    sharp_corners,
    archive_link_label
  } = settings;
  const {
    views = {},
    fields
  } = webStoriesData;

  const displayField = fieldName => (fields === null || fields === void 0 ? void 0 : fields[view][fieldName].show) && !(fields !== null && fields !== void 0 && fields[view][fieldName].hidden);

  if (!modalOpen) {
    return null;
  }

  return /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["Modal"], {
    onRequestClose: () => {
      Object(external_wp_data_["dispatch"])(store_name).toggleModal(false);
    },
    closeButtonLabel: Object(external_wp_i18n_["__"])('Close', 'web-stories'),
    title: Object(external_wp_i18n_["__"])('Web Stories', 'web-stories'),
    className: 'component_web_stories_mce_model',
    shouldCloseOnClickOutside: false
  }, /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["SelectControl"], {
    label: Object(external_wp_i18n_["__"])('Select Layout', 'web-stories'),
    value: view,
    options: views,
    onChange: view_type => {
      Object(external_wp_data_["dispatch"])(store_name).setCurrentView(view_type);
    }
  }), /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["RangeControl"], {
    label: Object(external_wp_i18n_["__"])('Number of Stories', 'web-stories'),
    value: number_of_stories,
    min: 1,
    max: 20,
    onChange: value => {
      updateViewSettings({
        fieldObj: Number(value),
        field: 'number_of_stories'
      });
    }
  }), /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["SelectControl"], {
    label: Object(external_wp_i18n_["__"])('Order By', 'web-stories'),
    value: orderby,
    options: [{
      value: 'post_date',
      label: Object(external_wp_i18n_["__"])('Date', 'web-stories')
    }, {
      value: 'post_title',
      label: Object(external_wp_i18n_["__"])('Title', 'web-stories')
    }],
    onChange: value => {
      updateViewSettings({
        fieldObj: value,
        field: 'orderby'
      });
    }
  }), /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["SelectControl"], {
    label: Object(external_wp_i18n_["__"])('Order', 'web-stories'),
    value: order,
    options: [{
      value: 'ASC',
      label: Object(external_wp_i18n_["__"])('Ascending', 'web-stories')
    }, {
      value: 'DESC',
      label: Object(external_wp_i18n_["__"])('Descending', 'web-stories')
    }],
    onChange: value => {
      updateViewSettings({
        fieldObj: value,
        field: 'order'
      });
    }
  }), /*#__PURE__*/external_React_default.a.createElement(Toggle, {
    field: "title",
    fieldObj: title
  }), /*#__PURE__*/external_React_default.a.createElement(Toggle, {
    field: "excerpt",
    fieldObj: excerpt
  }), /*#__PURE__*/external_React_default.a.createElement(Toggle, {
    field: "author",
    fieldObj: author
  }), /*#__PURE__*/external_React_default.a.createElement(Toggle, {
    field: "date",
    fieldObj: date
  }), displayField('image_alignment') && /*#__PURE__*/external_React_default.a.createElement("div", {
    style: {
      margin: '0 0 10px 0'
    }
  }, /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["RadioControl"], {
    label: Object(external_wp_i18n_["__"])('Image Alignment', 'web-stories'),
    selected: image_alignment,
    options: [{
      value: 'left',
      label: Object(external_wp_i18n_["__"])('Left', 'web-stories')
    }, {
      value: 'right',
      label: Object(external_wp_i18n_["__"])('Right', 'web-stories')
    }],
    onChange: value => {
      updateViewSettings({
        fieldObj: value,
        field: 'image_alignment'
      });
    }
  })), /*#__PURE__*/external_React_default.a.createElement(Toggle, {
    field: "sharp_corners",
    fieldObj: sharp_corners
  }), /*#__PURE__*/external_React_default.a.createElement(Toggle, {
    field: "archive_link",
    fieldObj: archive_link
  }), (archive_link === null || archive_link === void 0 ? void 0 : archive_link.show) && /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["TextControl"], {
    label: Object(external_wp_i18n_["__"])('Archive Link Label', 'web-stories'),
    value: archive_link_label,
    onChange: value => {
      updateViewSettings({
        fieldObj: value,
        field: 'archive_link_label'
      });
    }
  }), (circle_size === null || circle_size === void 0 ? void 0 : circle_size.show) && /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["RangeControl"], {
    label: Object(external_wp_i18n_["__"])('Circle Size', 'web-stories'),
    value: circle_size,
    min: 80,
    max: 200,
    step: 5,
    onChange: size => updateViewSettings({
      fieldObj: Number(size),
      field: 'circle_size'
    })
  }), displayField('number_of_columns') && /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["RangeControl"], {
    label: Object(external_wp_i18n_["__"])('Number of Columns', 'web-stories'),
    value: number_of_columns,
    min: 1,
    max: 4,
    onChange: value => updateViewSettings({
      fieldObj: Number(value),
      field: 'number_of_columns'
    })
  }), /*#__PURE__*/external_React_default.a.createElement("div", {
    style: {
      padding: '20px 0'
    },
    className: "alignright"
  }, /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["Button"], {
    isPrimary: true,
    onClick: () => {
      const editorInstance = Object(external_wp_data_["select"])(store_name).getEditor();

      if (editorInstance) {
        const shortcode = prepareShortCode();
        editorInstance.insertContent(shortcode);
      }

      Object(external_wp_data_["dispatch"])(store_name).toggleModal(false);
    }
  }, Object(external_wp_i18n_["__"])('Insert', 'web-stories')), /*#__PURE__*/external_React_default.a.createElement(external_wp_components_["Button"], {
    onClick: () => Object(external_wp_data_["dispatch"])(store_name).toggleModal(false)
  }, Object(external_wp_i18n_["__"])('Cancel', 'web-stories'))));
};

/* harmony default export */ var Modal = (WebStoriesModal);
// CONCATENATED MODULE: ./packages/tinymce-button/src/containers/Modal.js
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */




/**
 *
 * Pass extended props to the Modal component.
 *
 * @param {Function} select Store selector.
 * @return {Object} Injected props.
 */

const mapSelectToProps = select => {
  return {
    modalOpen: select(store_name).getModal(),
    settings: select(store_name).getCurrentViewSettings(),
    prepareShortCode: utils_prepareShortCode
  };
};
/**
 * Higher-order component.
 */


/* harmony default export */ var containers_Modal = (Object(external_wp_compose_["compose"])([Object(external_wp_data_["withSelect"])(mapSelectToProps)])(Modal));
// CONCATENATED MODULE: ./packages/tinymce-button/src/index.js


/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */




const {
  _
} = window;
/**
 * Add button to tinyMCE editor.
 */

/**
 * This is a patch for TinyMCE editor to insert content
 * using `insertContent` method.
 *
 * WP still uses `_.pluck` method
 * https://github.com/WordPress/WordPress/blob/master/wp-includes/js/mce-view.js#L145
 * lodash (which WP uses now) does not have this method, so there will be JS error in console.
 */
// eslint-disable-next-line no-prototype-builtins

if (!_.hasOwnProperty('pluck')) {
  _.pluck = _.map;
}
/**
 * Render tinyMCE settings modal.
 *
 * @class
 */


const RenderModal = () => {
  const target = document.getElementById('web-stories-tinymce');

  if (target) {
    Object(external_wp_element_["render"])( /*#__PURE__*/external_React_default.a.createElement(containers_Modal, null), target);
  }
};
/**
 * Subscribe to state change in store.
 */


store.subscribe(() => RenderModal());
tinymce.PluginManager.add('web_stories', function (editor) {
  editor.addButton('web_stories', {
    text: Object(external_wp_i18n_["__"])('Web Stories', 'web-stories'),
    classes: 'web-stories',
    image: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjA4IiBoZWlnaHQ9IjIwOCIgdmlld0JveD0iMCAwIDIwOCAyMDgiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxjaXJjbGUgY3g9IjEwMCIgY3k9IjEwMCIgcj0iMTAwIiBmaWxsPSJibGFjayIvPgo8cGF0aCBkPSJNMTM1LjIgNjIuNDAwNUMxNDAuOTQ0IDYyLjQwMDUgMTQ1LjYgNjcuMDU2NyAxNDUuNiA3Mi44MDA1VjEzNS4yQzE0NS42IDE0MC45NDQgMTQwLjk0NCAxNDUuNiAxMzUuMiAxNDUuNlY2Mi40MDA1WiIgZmlsbD0id2hpdGUiLz4KPHBhdGggZD0iTTU3LjIgNjIuNDAwNUM1Ny4yIDU2LjY1NjcgNjEuODU2MiA1Mi4wMDA1IDY3LjYgNTIuMDAwNUgxMTQuNEMxMjAuMTQ0IDUyLjAwMDUgMTI0LjggNTYuNjU2NyAxMjQuOCA2Mi40MDA1VjE0NS42QzEyNC44IDE1MS4zNDQgMTIwLjE0NCAxNTYgMTE0LjQgMTU2SDY3LjZDNjEuODU2MiAxNTYgNTcuMiAxNTEuMzQ0IDU3LjIgMTQ1LjZWNjIuNDAwNVoiIGZpbGw9IndoaXRlIi8+CjxwYXRoIGQ9Ik0xNTYgNzIuODAwNUMxNjAuMzA4IDcyLjgwMDUgMTYzLjggNzYuMjkyNyAxNjMuOCA4MC42MDA1VjEyNy40QzE2My44IDEzMS43MDggMTYwLjMwOCAxMzUuMiAxNTYgMTM1LjJWNzIuODAwNVoiIGZpbGw9IndoaXRlIi8+Cjwvc3ZnPg==',
    onclick: function () {
      Object(external_wp_data_["dispatch"])(store_name).setEditor(editor);
      Object(external_wp_data_["dispatch"])(store_name).toggleModal(true);
    }
  });
});

/***/ })
/******/ ]);