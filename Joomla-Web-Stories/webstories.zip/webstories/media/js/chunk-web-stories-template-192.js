(window["__webStories_webpackJsonp"] = window["__webStories_webpackJsonp"] || []).push([[74,135],{

/***/ 186:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _template__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(456);
var _template__WEBPACK_IMPORTED_MODULE_0___namespace = /*#__PURE__*/__webpack_require__.t(456, 1);
/* harmony import */ var _metaData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(300);
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Internal dependencies
 */


/* harmony default export */ __webpack_exports__["default"] = ({ ..._metaData__WEBPACK_IMPORTED_MODULE_1__["default"],
  ..._template__WEBPACK_IMPORTED_MODULE_0__
});

/***/ }),

/***/ 300:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2);
/* harmony import */ var _web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__);
/*
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * External dependencies
 */

/* harmony default export */ __webpack_exports__["default"] = ({
  slug: 'hawaii-travel-packing-list',
  creationDate: '2021-08-03T00:00:00.000Z',
  title: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Hawaii Travel Packing List', 'template name', 'web-stories'),
  tags: [Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Travel', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Island', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('List', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Nature', 'template keyword', 'web-stories'), Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Teal', 'template keyword', 'web-stories')],
  colors: [{
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Cool Teal', 'color', 'web-stories'),
    color: '#EFFAF6',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Blue', 'color', 'web-stories')
  }, {
    label: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Black', 'color', 'web-stories'),
    color: '#000',
    family: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Black', 'color', 'web-stories')
  }],
  description: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('This template’s beautiful blue-green palette will let you create helpful travel and backpacking stories such as tourist guides, packing lists, and more, with the ability to add product links.', 'web-stories'),
  vertical: Object(_web_stories_wp_i18n__WEBPACK_IMPORTED_MODULE_0__["_x"])('Travel', 'template vertical', 'web-stories')
});

/***/ })

}]);