# Module
---
### Folder `module`:
#### This is a `Module`. Modules are more lightweight and flexible extensions used for page rendering.
- This will be used to embed the `webstory` in the article.
- Just use the `{loadposition position}` or `{loadmoduleid moduleid}` to insert the module.