# Fields
---
### Folder `fields`:
- This is not a type of extension but it has been added to joomla project so that it allows the use to select the webstories which they want to embed.
- This folder will render fields for the article which will help author to select the `web story` they want to display.